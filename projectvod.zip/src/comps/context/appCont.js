import {createContext} from 'react';
 
export const AppCont = createContext(null);