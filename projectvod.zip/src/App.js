
import React from 'react';
import './App.css';
import AppVodBank from './comps/appVodBank';


function App() {


  return (
    <>
   <AppVodBank/>
    </>
  );
}

export default App;
